# Telegram bot placeholder
print("Replace token in environment variable BOT_TOKEN")