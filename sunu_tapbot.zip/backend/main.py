# Backend placeholder
from fastapi import FastAPI
app = FastAPI()
@app.get("/")
def root():
    return {"msg": "SUNU backend running"}